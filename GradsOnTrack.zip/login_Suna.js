function LoadMainPage() {
    location.assign("GradsOnTrack.html");
}