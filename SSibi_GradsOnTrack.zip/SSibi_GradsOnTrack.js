var MyScores = document.getElementById("Score");

MyScores.onclick = function showScores() {
    location.assign("View_Scores_Suna.html");
}