function EnableText() {
	location.assign("Edit_Scores_Suna.html");
}

function DisableText() {
	location.assign("View_Scores_Suna.html");
}